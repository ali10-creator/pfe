#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion
import math
import serial

class HoverboardOdometryNode(Node):
    def __init__(self):
        super().__init__('hoverboard_odometry_node')

        self.declare_parameters('', [
            ('wheel_radius', 0.08255),
            ('base_width', 0.3),
            ('serial_port', '/dev/ttyACM0'),
            ('baud_rate', 115200)
        ])

        self.wheel_radius = self.get_parameter('wheel_radius').value
        self.base_width = self.get_parameter('base_width').value
        self.ser = serial.Serial(
            self.get_parameter('serial_port').value,
            self.get_parameter('baud_rate').value,
            timeout=1
        )

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_time = self.get_clock().now()

        self.odom_pub = self.create_publisher(Odometry, '/demo/odom', 10)
        self.create_timer(0.1, self.read_serial)

    def read_serial(self):
        try:
            line = self.ser.readline().decode().strip()
            if not line.startswith("L:") or "R:" not in line:
                return

            parts = line.split()
            left_rpm = float(parts[0][2:])
            right_rpm = float(parts[1][2:])

            # Convert RPM to linear speed (v = 2*pi*r * (RPM/60))
            left_speed = 2 * math.pi * self.wheel_radius * (left_rpm / 60)
            right_speed = 2 * math.pi * self.wheel_radius * (right_rpm / 60)

            current_time = self.get_clock().now()
            dt = (current_time - self.last_time).nanoseconds / 1e9
            self.last_time = current_time

            v = (right_speed + left_speed) / 2.0
            omega = (right_speed - left_speed) / self.base_width

            delta_theta = omega * dt
            avg_theta = self.theta + delta_theta / 2.0

            self.x += v * math.cos(avg_theta) * dt
            self.y += v * math.sin(avg_theta) * dt
            self.theta += delta_theta
            self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

            odom = Odometry()
            odom.header.stamp = current_time.to_msg()
            odom.header.frame_id = 'odom'
            odom.child_frame_id = 'base_link'

            odom.pose.pose.position.x = self.x
            odom.pose.pose.position.y = self.y
            odom.pose.pose.orientation = Quaternion(
                x=0.0,
                y=0.0,
                z=math.sin(self.theta / 2.0),
                w=math.cos(self.theta / 2.0)
            )

            odom.twist.twist.linear.x = v
            odom.twist.twist.angular.z = omega

            self.odom_pub.publish(odom)

            self.get_logger().info(f"L: {left_rpm:.2f} RPM | R: {right_rpm:.2f} RPM | v = {v:.2f} m/s | w = {omega:.2f} rad/s")

        except Exception as e:
            self.get_logger().warn(f"Serial read error: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = HoverboardOdometryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
