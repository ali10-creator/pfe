import pandas as pd
import matplotlib.pyplot as plt
import time
import os
import signal
import sys

log_file = '/tmp/smc_cmd_log.csv'

plt.ion()
fig, (ax1, ax2, ax3, ax4) = plt.subplots(4, 1, figsize=(10, 12))

# Commanded vs Actual
line1, = ax1.plot([], [], label='Command v [m/s]')
line1_actual, = ax1.plot([], [], label='Actual v [m/s]', linestyle='--')
line2, = ax2.plot([], [], label='Command ω [rad/s]')
line2_actual, = ax2.plot([], [], label='Actual ω [rad/s]', linestyle='--')

# Errors
line_err_v, = ax3.plot([], [], label='Linear Error (v - v_actual)', color='tab:green')
line_err_omega, = ax3.plot([], [], label='Angular Error (ω - ω_actual)', color='tab:orange')

# Position error
line_pos_err, = ax4.plot([], [], label='Position Error [m]', color='tab:red')

# Labels and layout
ax1.set_ylabel('Linear velocity (v)')
ax2.set_ylabel('Angular velocity (ω)')
ax3.set_ylabel('Velocity Error')
ax4.set_ylabel('Position Error [m]')
ax4.set_xlabel('Time [s]')
for ax in [ax1, ax2, ax3, ax4]:
    ax.grid()
    ax.legend()

last_file_size = 0

def reset_plot():
    for line in [line1, line1_actual, line2, line2_actual, line_err_v, line_err_omega, line_pos_err]:
        line.set_data([], [])
    for ax in [ax1, ax2, ax3, ax4]:
        ax.relim()
        ax.autoscale_view()
    fig.canvas.draw()
    fig.canvas.flush_events()
    print("[INFO] Plot reset due to log file being cleared.")

def update():
    global last_file_size

    if not os.path.exists(log_file):
        return

    current_size = os.path.getsize(log_file)
    if current_size < last_file_size:
        reset_plot()

    last_file_size = current_size

    try:
        df = pd.read_csv(log_file)
    except pd.errors.EmptyDataError:
        return

    # Use the actual column names from the SMC_circular.py logger
    required_cols = ['v_actual', 'omega_actual', 'position_error']
    if df.shape[0] < 2 or not all(col in df.columns for col in required_cols):
        return

    df['v_err'] = df['v'] - df['v_actual']
    df['omega_err'] = df['omega'] - df['omega_actual']

    # Update plots
    line1.set_data(df['time'], df['v'])
    line1_actual.set_data(df['time'], df['v_actual'])
    line2.set_data(df['time'], df['omega'])
    line2_actual.set_data(df['time'], df['omega_actual'])
    line_err_v.set_data(df['time'], df['v_err'])
    line_err_omega.set_data(df['time'], df['omega_err'])
    line_pos_err.set_data(df['time'], df['position_error'])

    # Rescale axes
    for ax, data_min, data_max in zip(
        [ax1, ax2, ax3, ax4],
        [df[['v', 'v_actual']].min().min(), df[['omega', 'omega_actual']].min().min(),
         df[['v_err', 'omega_err']].min().min(), df['position_error'].min()],
        [df[['v', 'v_actual']].max().max(), df[['omega', 'omega_actual']].max().max(),
         df[['v_err', 'omega_err']].max().max(), df['position_error'].max()],
    ):
        ax.set_xlim(0, df['time'].max() + 0.1)
        ax.set_ylim(data_min - 0.05, data_max + 0.05)

    fig.suptitle("Live SMC Command vs Actual Velocity, Errors, and Position Error")
    fig.canvas.draw()
    fig.canvas.flush_events()

def signal_handler(sig, frame):
    print("\n[INFO] Plotting stopped by user.")
    plt.ioff()
    plt.close()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

while True:
    update()
    time.sleep(0.5)
